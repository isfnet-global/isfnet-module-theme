/**
 * ACTION JAVAscript. 
 * Control applicant/register page
 */
